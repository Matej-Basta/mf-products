declare const productsData: {
    id: number;
    name: string;
    price: number;
    description: string;
    image: string;
    longDescription: string;
}[];
export default productsData;
