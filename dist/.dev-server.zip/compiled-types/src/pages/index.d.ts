/// <reference types="node" />
/// <reference types="react" />
import { InferGetStaticPropsType } from 'next';
export declare const getStaticProps: (context: import("next").GetStaticPropsContext<import("querystring").ParsedUrlQuery, import("next").PreviewData>) => Promise<{
    props: {
        products: any;
    };
}>;
export default function Home({ products }: InferGetStaticPropsType<typeof getStaticProps>): import("react").JSX.Element;
