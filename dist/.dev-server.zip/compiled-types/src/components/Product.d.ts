/// <reference types="react" />
import ProductType from '../types/ProductInterface';
export default function Product({ product }: {
    product: ProductType;
}): import("react").JSX.Element;
